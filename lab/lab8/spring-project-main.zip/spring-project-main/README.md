# Spring-Project

## Env

> docker run --name OOAD_DB -e POSTGRES_PASSWORD=123456 -p 5432:5432 -d postgres:latest

## Info

- Swagger Path

> [swagger doc](http://localhost:8082/swagger-ui/index.html)